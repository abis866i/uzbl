var blocklist = new Array();
blocklist["IMG"]    = [["src", /.*doubleclick.net.*/i],
                       ["src", /.*last.fm\/adserver.*/i]];
 
blocklist["SCRIPT"] = [["src", /.*doubleclick.net.*/i]];
 
blocklist["IFRAME"] = [["name",  /.*google_ads.*/i],
                       ["id",    /.*ad-google.*/i],
                       ["id",    /.*widget.*/i],
                       ["src",   /.*facebook.*/i],
                       ["src",   /.*adsrv.*/i]];
 

function adblock(event)
{
    var tag = event.target.tagName;
    if (!blocklist[tag])
        return;
    for(var i = 0; i < blocklist[tag].length; i++) {
        if (event.target.getAttribute(blocklist[tag][i][0])) {
            if (event.target.getAttribute(blocklist[tag][i][0]).match(blocklist[tag][i][1])) {
                event.preventDefault();
                return;
            }
        }
    }
}
 
document.addEventListener("beforeload", adblock, true);

